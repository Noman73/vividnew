

<?php $__env->startSection('content'); ?>
<style>
    .select2-container .select2-selection--single{
        height: 40px !important;
    }
</style>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info">
                        Add Share Blance
                    </div>
                    <div class="card-body">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <?php echo implode('', $errors->all("<div class='text-danger'>:message</div>")); ?>

                        <?php endif; ?>
                        <form action="<?php echo e(route('mothlyadd.share.balance')); ?>" method="POST" ><?php echo csrf_field(); ?>
                            <label for="">Select User</label>
                            <select class="form-select form-control select2" aria-label="Default select example" style="width: 100%;" name="fuser_id" id="selectUser">
                                <option value="" selected>-- Select User --</option>
                                <?php $__currentLoopData = $fusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fuser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($fuser->fuser_id); ?>"><?php echo e(isset($fuser->user->name) ? $fuser->user->name : null); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                              <div id="details" class="text-success"></div>
                              <div class="row mt-5">
                                    
                                  <div class="col-md-6">
                                      <label for="">Profit Amount</label>
                                      <input type="number" class="form-control" name="profit_amount" placeholder="Profit Amount">
                                  </div>

                              </div>
                              <div class="row mt-4">
                                  <div class="col-md-12">
                                      <button class="btn btn-primary" type="submit">SEND</button>
                                  </div>
                              </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
   
<?php $__env->stopSection(); ?> 
<?php $__env->startSection('script'); ?>
<script src="jquery-3.5.1.min.js"></script>
<script>
    $(document).ready(function(){
        $('.select2').select2();
    });
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home6/vividcos/public_html/web/resources/views/pages/balance/share.blade.php ENDPATH**/ ?>